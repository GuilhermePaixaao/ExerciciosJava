package petshop.gerenciador;

import petshop.modelo.Agendamento; // import da classe do modelo
//Classe Pai
public class GerenciadorAgenda {
    private static Agendamento[] agenda = new Agendamento[10];//vetor fixo
    //Onde ocorre os agendamentos
    public static void agendar(Agendamento ag, int posicao) {
        if (agenda.length<=10) {
            if (agenda[posicao] != null) { //Verifica se existe horário na posição
                System.out.println("Horário ocupado!");
            } else {
                agenda[posicao] = ag;
                System.out.println("Agendamento feito!");
            }
        }
    }

    public static void listar() {
        for (int i = 0; i < agenda.length; i++) {
            if (agenda[i] == null) {
                System.out.println((i + 1) + " - Disponível");
            } else {
                System.out.println((i + 1) + " - " + agenda[i]);
            }
        }
    }

    public static void editar(int posicao, String novoNomePet, String novoNomeDono) {
        if (agenda[posicao] != null) {
            agenda[posicao].setNomePet(novoNomePet);
            agenda[posicao].setNomeDono(novoNomeDono);
            System.out.println("Agendamento atualizado!");
        } else {
            System.out.println("Não há agendamento nesse horário.");
        }
    }

    public static void excluir(int posicao) {
        if (agenda[posicao] != null) {
            agenda[posicao] = null;
            System.out.println("Agendamento cancelado!");
        } else {
            System.out.println("Não há agendamento nesse horário.");
        }
    }
}
