package petshop.modelo; // pacote correto

public class Agendamento {
    private String nomePet;
    private String especie;
    private String nomeDono;
    private String telefoneDono;
    private String horario;
    private String servicoAdicional;

    public Agendamento(String nomePet, String especie, String nomeDono, String telefoneDono, String horario, String servicoAdicional) {
        this.nomePet = nomePet;
        this.especie = especie;
        this.nomeDono = nomeDono;
        this.telefoneDono = telefoneDono;
        this.horario = horario;
        this.servicoAdicional = servicoAdicional;
    }

    public String getNomePet() { return nomePet; }
    public void setNomePet(String nomePet) { this.nomePet = nomePet; }

    public String getNomeDono() { return nomeDono; }
    public void setNomeDono(String nomeDono) { this.nomeDono = nomeDono; }

    public String getHorario() { return horario; }

    @Override
    public String toString() {
        return horario + " - Pet: " + nomePet + " (" + especie + "), Dono: " + nomeDono;
    }
}
