package petshop.modelo;
//Classe filho
public class BanhoComTosa extends Agendamento {
    public BanhoComTosa(String nomePet, String especie, String nomeDono, String telefoneDono, String horario) {
        super(nomePet, especie, nomeDono, telefoneDono, horario, "Banho + Tosa");
    }
}
