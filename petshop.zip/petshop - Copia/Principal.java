package petshop;

import petshop.modelo.*;
import petshop.gerenciador.GerenciadorAgenda;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("\n--- Menu Pet Shop ---");
            System.out.println("1 - Agendar banho");
            System.out.println("2 - Consultar agenda");
            System.out.println("3 - Editar agendamento");
            System.out.println("4 - Excluir agendamento");
            System.out.println("5 - Sair");
            System.out.print("Escolha: ");
            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {
                case 1:
                    System.out.print("Nome do Pet: ");
                    String nomePet = sc.nextLine();
                    System.out.print("Espécie: ");
                    String especie = sc.nextLine();
                    System.out.print("Nome do Dono: ");
                    String nomeDono = sc.nextLine();
                    System.out.print("Telefone do Dono: ");
                    String telefone = sc.nextLine();
                    System.out.print("Horário (1 a 10): ");
                    int posicao = sc.nextInt() - 1;
                    sc.nextLine();

                    System.out.println("Tipo de serviço: 1 - Simples | 2 - Com Tosa");
                    int tipo = sc.nextInt();
                    sc.nextLine();

                    Agendamento ag;
                    if (tipo == 1) {
                        ag = new BanhoSimples(nomePet, especie, nomeDono, telefone, "Horário " + (posicao+1));
                    } else {
                        ag = new BanhoComTosa(nomePet, especie, nomeDono, telefone, "Horário " + (posicao+1));
                    }

                    GerenciadorAgenda.agendar(ag, posicao);
                    break;

                case 2:
                    GerenciadorAgenda.listar();
                    break;

                case 3:
                    System.out.print("Digite o horário (1 a 10) para editar: ");
                    int editarPos = sc.nextInt() - 1;
                    sc.nextLine();
                    System.out.print("Novo nome do pet: ");
                    String novoPet = sc.nextLine();
                    System.out.print("Novo nome do dono: ");
                    String novoDono = sc.nextLine();
                    GerenciadorAgenda.editar(editarPos, novoPet, novoDono);
                    break;

                case 4:
                    System.out.print("Digite o horário (1 a 10) para excluir: ");
                    int excluirPos = sc.nextInt() - 1;
                    GerenciadorAgenda.excluir(excluirPos);
                    break;

                case 5:
                    System.out.println("Saindo...");
                    break;

                default:
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 5);

        sc.close();
    }
}
